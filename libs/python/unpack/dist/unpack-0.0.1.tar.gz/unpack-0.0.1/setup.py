import setuptools

setuptools.setup(
    name="unpack",
    version="0.0.1",
    author="Mihir Joshi",
    author_email="author@example.com",
    description="A small example package",
    packages=setuptools.find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
)
